Kelompok 9
Nama Anggota : 

1. Henk Natalis Aibekob (00000065012) 
2. Raka barajasena (00000063511) 
3. Alfianto Saputra (00000064023) 
4. Nicholas Sherafin reganta (00000066374)

Aturan permainan (gameplay) yang diterapkan pada aplikasi kita adalah pertama kita harus menginput nama pemain dan game sudah bisa langsung di mainkan